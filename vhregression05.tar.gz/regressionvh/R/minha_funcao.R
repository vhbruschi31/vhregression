library(minpack.lm)
library(ggplot2)
library(gridExtra)
library(openxlsx)
library(readxl)

modelos_disponiveis <- c(
  "Logistic", "Gompertz", "MMF", "Weibull", "Exponential",
  "Modified Exponential", "Logarithmic", "Reciprocal Logarithm", "Vapor Pressure",
  "Power Fit", "Modified Power", "Shifted Power", "Geometric",
  "Modified Geometric", "Hoerl Model", "Exponential Associative 2",
  "Exponential Associative 3", "Sinusoidal", "Gaussian",
  "Hyperbolic", "Heat Capacity", "Rational", "Richards","Asymptotic","Harris","Brody","Wilmink"
)


modelos_selecionados <- c( "Logistic", "Gompertz", "MMF", "Weibull", "Exponential",
                           "Modified Exponential", "Logarithmic", "Reciprocal Logarithm", "Vapor Pressure",
                           "Power Fit", "Modified Power", "Shifted Power", "Geometric",
                           "Modified Geometric", "Hoerl Model", "Exponential Associative 2",
                           "Exponential Associative 3", "Sinusoidal", "Gaussian",
                           "Hyperbolic", "Heat Capacity", "Rational", "Richards","Asymptotic","Harris","Brody","Wilmink")

nome_arquivo_pdf <- "ajustes.pdf"


ajustar_modelo_wilmink <- function(dados) {
  modelo_wilmink <- function(x, a, b, c, d) {
    a - b * x + c * exp(-d * x)
  }

    a_inicial <- mean(dados$y, na.rm = TRUE)  
  b_inicial <- 0 
  c_inicial <- max(dados$y, na.rm = TRUE)  
  d_inicial <- 0.1  

  parametros_iniciais <- list(
    a = a_inicial,
    b = b_inicial,
    c = c_inicial,
    d = d_inicial
  )

    ajuste <- tryCatch({
    nlsLM(
      y ~ modelo_wilmink(x, a, b, c, d),
      data = dados,
      start = parametros_iniciais,
      control = nls.lm.control(maxiter = 100)
    )
  }, error = function(e) {
    cat("Erro no ajuste do modelo:", e$message, "\n")
    return(NULL)
  })

  return(ajuste)
}



ajustar_modelo_brody <- function(dados) {
  modelo_brody <- function(x, a, b) {
    a * exp(-b * x)
  }

  
  a_inicial <- max(dados$y, na.rm = TRUE)  
  b_inicial <- 0.1  

  parametros_iniciais <- list(
    a = a_inicial,
    b = b_inicial
  )

    ajuste <- tryCatch({
    nlsLM(
      y ~ modelo_brody(x, a, b),
      data = dados,
      start = parametros_iniciais,
      control = nls.lm.control(maxiter = 100)
    )
  }, error = function(e) {
    cat("Erro no ajuste do modelo:", e$message, "\n")
    return(NULL)
  })

  return(ajuste)
}

ajustar_modelo_harris <- function(dados) {
  modelo_harris <- function(x, a, b, c) {
    1 / (a + b * x^c)
  }

  
  a_inicial <- 1
  b_inicial <- 1
  c_inicial <- 1

  parametros_iniciais <- list(
    a = a_inicial,
    b = b_inicial,
    c = c_inicial
  )

 
  ajuste <- tryCatch({
    nlsLM(
      y ~ modelo_harris(x, a, b, c),
      data = dados,
      start = parametros_iniciais,
      control = nls.lm.control(maxiter = 100)
    )
  }, error = function(e) {
    cat("Erro no ajuste do modelo:", e$message, "\n")
    return(NULL)
  })

  return(ajuste)
}


ajustar_modelo_asymptotic <- function(dados) {
  modelo_asymptotic <- function(x, a, b, c) {
    a + (b - a) * exp(-exp(c) * x)
  }

  parametros_iniciais <- list(a = 1, b = 1, c = 1)

  ajuste <- tryCatch({
    nlsLM(y ~ modelo_asymptotic(x, a, b, c),
          data = dados,
          start = parametros_iniciais,
          control = nls.lm.control(maxiter = 200))
  }, error = function(e) {
    message("Ajuste do modelo assintótico falhou: ", e$message)
    NULL
  })

  return(ajuste)
}


ajustar_modelo_richards <- function(dados) {
  modelo_richards <- function(x, a, b, c, d) {
    a / (1 + exp(b - c * x))^(1 / d)
  }

  d_inicial <- 1

  a_inicial <- max(dados$y, na.rm = TRUE)

  x_med <- mean(dados$x, na.rm = TRUE)
  y_med <- mean(dados$y, na.rm = TRUE)

  parametros_iniciais <- list(
    a = a_inicial,
    b = 1,
    c = 0.1,
    d = d_inicial
  )

  ajuste <- tryCatch({
    nlsLM(
      y ~ modelo_richards(x, a, b, c, d),
      data = dados,
      start = parametros_iniciais,
      control = nls.lm.control(maxiter = 100)
    )
  }, error = function(e) {
    cat("Erro no ajuste do modelo:", e$message, "\n")
    return(NULL)
  })

  return(ajuste)
}



ajustar_modelo_logistico <- function(dados) {
  modelo_logistico_tres_parametros <- function(x, a, b, c) {
    a / (1 + exp(b - c * x))
  }

  parametros_iniciais <- list(a = 25, b = -0.1, c = 0.1)

  ajuste <- nlsLM(y ~ modelo_logistico_tres_parametros(x, a, b, c),
                  data = dados,
                  start = parametros_iniciais,
                  lower = c(a = 0, b = -Inf, c = -Inf),
                  upper = c(a = Inf, b = Inf, c = Inf))

  return(ajuste)
}

ajustar_modelo_gompertz <- function(dados) {
  modelo_gompertz <- function(x, a, b, c) {
    a * exp(-exp(b - c * x))
  }

  parametros_iniciais <- list(a = 25, b = 1, c = 0.1)

  ajuste <- nlsLM(y ~ modelo_gompertz(x, a, b, c),
                  data = dados,
                  start = parametros_iniciais,
                  lower = c(a = 0, b = -Inf, c = -Inf),
                  upper = c(a = Inf, b = Inf, c = Inf))

  return(ajuste)
}

ajustar_modelo_mmf <- function(dados) {
  modelo_mmf <- function(x, a, b, c, d) {
    (a * b + c * x^d) / (b + x^d)
  }

  dados <- dados[complete.cases(dados), ]

  a_inicial <- max(dados$y, na.rm = TRUE)
  b_inicial <- min(dados$y, na.rm = TRUE)
  c_inicial <- 0.1 * (max(dados$y, na.rm = TRUE) - min(dados$y, na.rm = TRUE))
  d_inicial <- 1

  parametros_iniciais <- list(
    a = a_inicial,
    b = b_inicial,
    c = c_inicial,
    d = d_inicial
  )

  ajuste <- tryCatch({
    nlsLM(
      y ~ modelo_mmf(x, a, b, c, d),
      data = dados,
      start = parametros_iniciais,
      control = nls.lm.control(maxiter = 200)
    )
  }, error = function(e) {
    message("Ajuste do modelo MMF falhou: ", e$message)
    NULL
  })

  return(ajuste)
}

ajustar_modelo_weibull <- function(dados) {
  modelo_weibull <- function(x, a, b, c, d) {
    a - b * exp(-c * x^d)
  }

  parametros_iniciais <- list(a = max(dados$y),
                              b = max(dados$y) - min(dados$y),
                              c = 0.01,
                              d = 1)

  ajuste <- tryCatch({
    nlsLM(y ~ modelo_weibull(x, a, b, c, d),
          data = dados,
          start = parametros_iniciais,
          control = nls.lm.control(maxiter = 200))
  }, error = function(e) {
    message("Ajuste do modelo Weibull falhou: ", e$message)
    NULL
  })

  return(ajuste)
}

ajustar_modelo_exp_assoc2 <- function(dados) {
  modelo_exp_assoc2 <- function(x, a, b) {
    a * (1 - exp(-b * x))
  }

  parametros_iniciais <- list(a = max(dados$y), b = 0.1)

  ajuste <- tryCatch({
    nlsLM(y ~ modelo_exp_assoc2(x, a, b),
          data = dados,
          start = parametros_iniciais,
          control = nls.lm.control(maxiter = 100))
  }, error = function(e) {
    message("Ajuste do modelo Exponential Associative 2 falhou: ", e$message)
    NULL
  })

  return(ajuste)
}

ajustar_modelo_exp_assoc3 <- function(dados) {
  modelo_exp_assoc3 <- function(x, a, b, c) {
    a * (b - exp(-c * x))
  }

  parametros_iniciais <- list(a = max(dados$y), b = mean(dados$y), c = 0.1)

  ajuste <- tryCatch({
    nlsLM(y ~ modelo_exp_assoc3(x, a, b, c),
          data = dados,
          start = parametros_iniciais,
          control = nls.lm.control(maxiter = 100))
  }, error = function(e) {
    message("Ajuste do modelo Exponential Associative 3 falhou: ", e$message)
    NULL
  })

  return(ajuste)
}

ajustar_modelo_sinusoidal <- function(dados) {
  modelo_sinusoidal <- function(x, a, b, c, d) {
    a + b * cos(c * x + d)
  }

  parametros_iniciais <- list(a = 1, b = 1, c = 1, d = 0)

  ajuste <- tryCatch({
    nlsLM(y ~ modelo_sinusoidal(x, a, b, c, d),
          data = dados,
          start = parametros_iniciais,
          control = nls.lm.control(maxiter = 100))
  }, error = function(e) {
    message("Ajuste do modelo Sinusoidal falhou: ", e$message)
    NULL
  })

  return(ajuste)
}

ajustar_modelo_gaussian <- function(dados) {
  modelo_gaussian <- function(x, a, b, c) {
    a * exp(-((x - b)^2) / (2 * c^2))
  }

  parametros_iniciais <- list(a = max(dados$y), b = mean(dados$x), c = sd(dados$x))

  ajuste <- tryCatch({
    nlsLM(y ~ modelo_gaussian(x, a, b, c),
          data = dados,
          start = parametros_iniciais,
          control = nls.lm.control(maxiter = 100))
  }, error = function(e) {
    message("Ajuste do modelo Gaussian falhou: ", e$message)
    NULL
  })

  return(ajuste)
}

ajustar_modelo_hyperbolic <- function(dados) {
  modelo_hyperbolic <- function(x, a, b) {
    a + b / x
  }

  parametros_iniciais <- list(a = min(dados$y), b = 1)

  ajuste <- tryCatch({
    nlsLM(y ~ modelo_hyperbolic(x, a, b),
          data = dados,
          start = parametros_iniciais,
          control = nls.lm.control(maxiter = 100))
  }, error = function(e) {
    message("Ajuste do modelo Hyperbolic falhou: ", e$message)
    NULL
  })

  return(ajuste)
}

ajustar_modelo_heat_capacity <- function(dados) {
  modelo_heat_capacity <- function(x, a, b, c) {
    a + b * x + c / x^2
  }

  parametros_iniciais <- list(a = min(dados$y), b = 1, c = 1)

  ajuste <- tryCatch({
    nlsLM(y ~ modelo_heat_capacity(x, a, b, c),
          data = dados,
          start = parametros_iniciais,
          control = nls.lm.control(maxiter = 100))
  }, error = function(e) {
    message("Ajuste do modelo Heat Capacity falhou: ", e$message)
    NULL
  })

  return(ajuste)
}

ajustar_modelo_rational <- function(dados) {
  modelo_rational <- function(x, a, b, c, d) {
    (a + b * x) / (1 + c * x + d * x^2)
  }

  parametros_iniciais <- list(a = min(dados$y), b = 1, c = 1, d = 1)

  ajuste <- tryCatch({
    nlsLM(y ~ modelo_rational(x, a, b, c, d),
          data = dados,
          start = parametros_iniciais,
          control = nls.lm.control(maxiter = 100))
  }, error = function(e) {
    message("Ajuste do modelo Rational falhou: ", e$message)
    NULL
  })

  return(ajuste)
}


ajustar_modelo_power_fit <- function(dados) {
  modelo_power_fit <- function(x, a, b) {
    a * x^b
  }

  parametros_iniciais <- list(a = 1, b = 1)

  ajuste <- tryCatch({
    nlsLM(y ~ modelo_power_fit(x, a, b),
          data = dados,
          start = parametros_iniciais)
  }, error = function(e) {
    message("Ajuste do modelo Power Fit falhou: ", e$message)
    NULL
  })

  return(ajuste)
}

ajustar_modelo_modified_power <- function(dados) {
  modelo_modified_power <- function(x, a, b) {
    a * b^x
  }

  parametros_iniciais <- list(a = 1, b = 1)

  ajuste <- tryCatch({
    nlsLM(y ~ modelo_modified_power(x, a, b),
          data = dados,
          start = parametros_iniciais)
  }, error = function(e) {
    message("Ajuste do modelo Modified Power falhou: ", e$message)
    NULL
  })

  return(ajuste)
}

ajustar_modelo_shifted_power <- function(dados) {
  modelo_shifted_power <- function(x, a, b, c) {
    a * (x - b)^c
  }

  parametros_iniciais <- list(a = 1, b = 1, c = 1)

  ajuste <- tryCatch({
    nlsLM(y ~ modelo_shifted_power(x, a, b, c),
          data = dados,
          start = parametros_iniciais)
  }, error = function(e) {
    message("Ajuste do modelo Shifted Power falhou: ", e$message)
    NULL
  })

  return(ajuste)
}


ajustar_modelo_geometric <- function(dados) {
  modelo_geometric <- function(x, a, b) {
    a * x^(b * x)
  }

  parametros_iniciais <- list(a = 1, b = 0.1)

  controle <- nls.lm.control(maxiter = 100, ftol = 1e-8, ptol = 1e-8, gtol = 1e-8)

  ajuste <- tryCatch({
    nlsLM(y ~ modelo_geometric(x, a, b),
          data = dados,
          start = parametros_iniciais,
          control = controle)
  }, error = function(e) {
    message("Ajuste do modelo Geometric falhou: ", e$message)
    NULL
  })

  return(ajuste)
}

ajustar_modelo_modified_geometric <- function(dados) {
  modelo_modified_geometric <- function(x, a, b) {
    a * x^(b / x)
  }

  parametros_iniciais <- list(a = 1, b = 1)

  controle <- nls.lm.control(maxiter = 100, ftol = 1e-8, ptol = 1e-8, gtol = 1e-8)

  ajuste <- tryCatch({
    nlsLM(y ~ modelo_modified_geometric(x, a, b),
          data = dados,
          start = parametros_iniciais,
          control = controle)
  }, error = function(e) {
    message("Ajuste do modelo Modified Geometric falhou: ", e$message)
    NULL
  })

  return(ajuste)
}

ajustar_modelo_hoerl <- function(dados) {
  modelo_hoerl <- function(x, a, b, c) {
    a * (b^x) * (x^c)
  }

  parametros_iniciais <- list(a = 1, b = 1, c = 1)

  ajuste <- tryCatch({
    nlsLM(y ~ modelo_hoerl(x, a, b, c),
          data = dados,
          start = parametros_iniciais)
  }, error = function(e) {
    message("Ajuste do modelo Hoerl falhou: ", e$message)
    NULL
  })

  return(ajuste)
}
ajustar_modelo_exponencial <- function(dados) {
  modelo_exponencial <- function(x, a, b) {
    a * exp(b * x)
  }

  parametros_iniciais <- list(a = 1, b = 0.1)

  ajuste <- tryCatch({
    nlsLM(y ~ modelo_exponencial(x, a, b),
          data = dados,
          start = parametros_iniciais)
  }, error = function(e) {
    message("Ajuste do modelo Exponential falhou: ", e$message)
    NULL
  })

  return(ajuste)
}

ajustar_modelo_exponential_modified <- function(dados) {
  modelo_exponencial_modificado <- function(x, a, b) {
    a * exp(b / x)
  }

  parametros_iniciais <- list(a = 1, b = 0.1)

  ajuste <- tryCatch({
    nlsLM(y ~ modelo_exponencial_modificado(x, a, b),
          data = dados,
          start = parametros_iniciais)
  }, error = function(e) {
    message("Ajuste do modelo Modified Exponential falhou: ", e$message)
    NULL
  })

  return(ajuste)
}
ajustar_modelo_logaritmico <- function(dados) {
  modelo_logaritmico <- function(x, a, b) {
    a + b * log(x)
  }

  parametros_iniciais <- list(a = 1, b = 0.1)

  ajuste <- nlsLM(y ~ modelo_logaritmico(x, a, b),
                  data = dados,
                  start = parametros_iniciais)

  return(ajuste)
}

ajustar_modelo_reciprocal_log <- function(dados) {
  modelo_reciprocal_log <- function(x, a, b) {
    1 / (a + b * log(x))
  }

  parametros_iniciais <- list(a = 1, b = 0.1)

  ajuste <- nlsLM(y ~ modelo_reciprocal_log(x, a, b),
                  data = dados,
                  start = parametros_iniciais)

  return(ajuste)
}

ajustar_modelo_vapor_pressure <- function(dados) {
  modelo_vapor_pressure <- function(x, a, b, c) {
    exp(a + b / x + c * log(x))
  }

  parametros_iniciais <- list(a = 1, b = 1, c = 0.1)

  ajuste <- nlsLM(y ~ modelo_vapor_pressure(x, a, b, c),
                  data = dados,
                  start = parametros_iniciais)

  return(ajuste)
}





# Função para ajustar os modelos e calcular o R²
ajustar_modelos_e_calcular_r2 <- function(dados, modelos) {
  resultados <- list()

  for (nome_modelo in names(modelos)) {
    ajuste <- modelos[[nome_modelo]]

    if (!is.null(ajuste)) {
      residuos <- residuals(ajuste)
      erro_residual <- sqrt(sum(residuos^2) / length(residuos))
      r_quadrado <- 1 - sum(residuos^2) / sum((dados$y - mean(dados$y))^2)

      resultados[[nome_modelo]] <- list(
        ajuste = ajuste,
        r_quadrado = r_quadrado,
        erro_residual = erro_residual
      )
    }
  }

  return(resultados)
}

gerar_subtitulo <- function(modelo, parametros) {
  switch(modelo,
         "Logarithmic" = paste0("y = ", sprintf("%.3f", parametros[1]), " + ", sprintf("%.3f", parametros[2]), " * ln(x)"),
         "Reciprocal Logarithm" = paste0("y = 1 / (", sprintf("%.3f", parametros[1]), " + ", sprintf("%.3f", parametros[2]), " * ln(x))"),
         "Vapor Pressure" = paste0("y = exp(", sprintf("%.3f", parametros[1]), " + ", sprintf("%.3f", parametros[2]), " / x + ", sprintf("%.3f", parametros[3]), " * ln(x))"),
         "Exponential" = paste0("y = ", sprintf("%.3f", parametros[1]), " * exp(", sprintf("%.3f", parametros[2]), " * x)"),
         "Modified Exponential" = paste0("y = ", sprintf("%.3f", parametros[1]), " * exp(", sprintf("%.3f", parametros[2]), " / x)"),
         "Logistic" = paste0("y = ", sprintf("%.3f", parametros[1]), " / (1 + exp(-(", sprintf("%.3f", parametros[2]), " * (x - ", sprintf("%.3f", parametros[3]), "))))"),
         "Gompertz" = paste0("y = ", sprintf("%.3f", parametros[1]), " * exp(-exp(", sprintf("%.3f", parametros[2]), " * (", sprintf("%.3f", parametros[3]), " - x)))"),
         "MMF" = paste0("y = (", sprintf("%.3f", parametros[1]), " * ", sprintf("%.3f", parametros[2]), " + ", sprintf("%.3f", parametros[3]), " * x^", sprintf("%.3f", parametros[4]), ") / (", sprintf("%.3f", parametros[2]), " + x^", sprintf("%.3f", parametros[4]), ")"),
         "Weibull" = paste0("y = ", sprintf("%.3f", parametros[1]), " - ", sprintf("%.3f", parametros[2]), " * exp(-(", sprintf("%.3f", parametros[3]), " * x)^", sprintf("%.3f", parametros[4]), ")"),
         "Exponential Associative 2" = paste0("y = ", sprintf("%.3f", parametros[1]), " * (1 - exp(-", sprintf("%.3f", parametros[2]), " * x))"),
         "Exponential Associative 3" = paste0("y = ", sprintf("%.3f", parametros[1]), " * (", sprintf("%.3f", parametros[2]), " - exp(-", sprintf("%.3f", parametros[3]), " * x))"),
         "Sinusoidal" = paste0("y = ", sprintf("%.3f", parametros[1]), " + ", sprintf("%.3f", parametros[2]), " * sin(", sprintf("%.3f", parametros[3]), " * x + ", sprintf("%.3f", parametros[4]), ")"),
         "Gaussian" = paste0("y = ", sprintf("%.3f", parametros[1]), " * exp(-((x - ", sprintf("%.3f", parametros[2]), ")^2) / (2 * ", sprintf("%.3f", parametros[3]), "^2))"),
         "Hyperbolic" = paste0("y = ", sprintf("%.3f", parametros[1]), " + ", sprintf("%.3f", parametros[2]), " / x"),
         "Heat Capacity" = paste0("y = ", sprintf("%.3f", parametros[1]), " + ", sprintf("%.3f", parametros[2]), " * x + ", sprintf("%.3f", parametros[3]), " / x^2"),
         "Rational" = paste0("y = (", sprintf("%.3f", parametros[1]), " + ", sprintf("%.3f", parametros[2]), " * x) / (1 + ", sprintf("%.3f", parametros[3]), " * x + ", sprintf("%.3f", parametros[4]), " * x^2)"),
         "Power Fit" = paste0("y = ", sprintf("%.3f", parametros[1]), " * x^", sprintf("%.3f", parametros[2]), " "),
         "Modified Power" = paste0("y = ", sprintf("%.3f", parametros[1]), " * ", sprintf("%.3f", parametros[2]), "^x"),
         "Shifted Power" = paste0("y = ", sprintf("%.3f", parametros[1]), " * (x - ", sprintf("%.3f", parametros[2]), ")^", sprintf("%.3f", parametros[3]), " "),
         "Geometric" = paste0("y = ", sprintf("%.3f", parametros[1]), " * x^(", sprintf("%.3f", parametros[2]), " * x)"),
         "Modified Geometric" = paste0("y = ", sprintf("%.3f", parametros[1]), " * x^(", sprintf("%.3f", parametros[2]), " / x)"),
         "Hoerl Model" = paste0("y = ", sprintf("%.3f", parametros[1]), " * (", sprintf("%.3f", parametros[2]), " ^ x) * (x ^ ", sprintf("%.3f", parametros[3]), ")"),
         "Asymptotic" = paste0("y = ", sprintf("%.3f", parametros[1]), " + (", sprintf("%.3f", parametros[2]), " - ", sprintf("%.3f", parametros[1]), ") * exp(-exp(", sprintf("%.3f", parametros[3]), ") * x)"),
         "Richards" = paste0("y = ", sprintf("%.3f", parametros[1]), " / (1 + exp(", sprintf("%.3f", parametros[2]), " - ", sprintf("%.3f", parametros[3]), " * x))^(1 / ", sprintf("%.3f", parametros[4]), ")"),
         "Harris" = paste0("y = 1 / (", sprintf("%.3f", parametros[1]), " + ", sprintf("%.3f", parametros[2]), " * x^", sprintf("%.3f", parametros[3]), ")"),
         "Brody" = paste0("y = ", sprintf("%.3f", parametros[1]), " * exp(-", sprintf("%.3f", parametros[2]), " * x)"),
         "Wilmink" = paste0("y = ", sprintf("%.3f", parametros[1]), " + ", sprintf("%.3f", parametros[2]), " * x + ", sprintf("%.3f", parametros[3]), " * exp(-", sprintf("%.3f", parametros[4]), " * x)"))


}



plot_modelo <- function(ajuste, dados, nome_modelo) {
  previsao <- predict(ajuste, newdata = dados)
  residuos <- residuals(ajuste)
  r_quadrado <- 1 - sum(residuos^2) / sum((dados$y - mean(dados$y))^2)
  erro_residual <- sqrt(mean(residuos^2))

 
  parametros <- coef(ajuste)


  subtitulo <- gerar_subtitulo(nome_modelo, parametros)


  p1 <- ggplot(dados, aes(x = x, y = y)) +
    geom_point(color = "black",alpha = 0.6) +
    geom_line(aes(y = previsao), color = "red") +
    labs(title = paste(nome_modelo, "R²:", round(r_quadrado, 3), "S:", round(erro_residual, 3)),
         subtitle = subtitulo,
         x = "x", y = "y") +
    theme_minimal() +
    theme(plot.title = element_text(size = 10, face = "bold", color = "black"),
          plot.subtitle = element_text(size = 6.4, face = "italic", color = "black"),
          axis.title = element_text(size = 8),
          axis.text = element_text(size = 6),
          plot.margin = margin(2, 2, 2, 2),
          panel.border = element_rect(color = "black", fill = NA)) +
    theme(aspect.ratio = 0.7)

 
  p2 <- ggplot(dados, aes(x = x, y = residuos)) +
    geom_point(color = "black", alpha = 0.6) +
    geom_hline(yintercept = 0, color = "red") +
    labs(title = paste(nome_modelo),
         subtitle = "Resíduos",
         x = "x", y= "y" ) +
    theme_minimal() +
    theme(plot.title = element_text(size = 10, face = "bold", color = "black"),
          plot.subtitle = element_text(size = 6.4, face = "italic", color = "black"),
          axis.title = element_text(size = 8),
          axis.text = element_text(size = 6),
          plot.margin = margin(2, 2, 2, 2),
          panel.border = element_rect(color = "black", fill = NA)) +
    theme(aspect.ratio = 0.7)

  return(list(p1, p2))
}


importar_dados <- function() {
  caminho_arquivo <- file.choose()  

  dados <- tryCatch({
    read_excel(caminho_arquivo) 
  }, error = function(e) {
    cat("Erro ao importar o arquivo: ", e$message, "\n")
    return(NULL)
  })

  return(dados)
}

  
  analise_completa <- function(dados, modelos_selecionados, nome_arquivo_pdf = "ajustes.pdf", nome_arquivo_excel = "modelos_ajustados.xlsx") {
    dados <- importar_dados()
   
    resultados <- list()

       for (nome_modelo in modelos_selecionados) {
      ajuste <- switch(nome_modelo,
                       "Wilmink" = ajustar_modelo_wilmink(dados),
                       "Brody" = ajustar_modelo_brody(dados),
                       "Harris" = ajustar_modelo_harris(dados),
                       "Asymptotic" = ajustar_modelo_asymptotic(dados),
                       "Richards" = ajustar_modelo_richards(dados),
                       "Logarithmic" = ajustar_modelo_logaritmico(dados),
                       "Reciprocal Logarithm" = ajustar_modelo_reciprocal_log(dados),
                       "Vapor Pressure" = ajustar_modelo_vapor_pressure(dados),
                       "Exponential" = ajustar_modelo_exponencial(dados),
                       "Modified Exponential" = ajustar_modelo_exponential_modified(dados),
                       "Logistic" = ajustar_modelo_logistico(dados),
                       "Gompertz" = ajustar_modelo_gompertz(dados),
                       "MMF" = ajustar_modelo_mmf(dados),
                       "Weibull" = ajustar_modelo_weibull(dados),
                       "Exponential Associative 2" = ajustar_modelo_exp_assoc2(dados),
                       "Exponential Associative 3" = ajustar_modelo_exp_assoc3(dados),
                       "Sinusoidal" = ajustar_modelo_sinusoidal(dados),
                       "Gaussian" = ajustar_modelo_gaussian(dados),
                       "Hyperbolic" = ajustar_modelo_hyperbolic(dados),
                       "Heat Capacity" = ajustar_modelo_heat_capacity(dados),
                       "Rational" = ajustar_modelo_rational(dados),
                       "Power Fit" = ajustar_modelo_power_fit(dados),
                       "Modified Power" = ajustar_modelo_modified_power(dados),
                       "Shifted Power" = ajustar_modelo_shifted_power(dados),
                       "Geometric" = ajustar_modelo_geometric(dados),
                       "Modified Geometric" = ajustar_modelo_modified_geometric(dados),
                       "Hoerl Model" = ajustar_modelo_hoerl(dados),
                       NULL)

      if (!is.null(ajuste)) {
        residuos <- residuals(ajuste)
        r_quadrado <- 1 - sum(residuos^2) / sum((dados$y - mean(dados$y))^2)
        resultados[[nome_modelo]] <- list(ajuste = ajuste, r_quadrado = r_quadrado)
      }
    }

       modelos_ordenados <- names(sort(sapply(resultados, function(x) x$r_quadrado), decreasing = TRUE))

    
    pdf(nome_arquivo_pdf, width = 12, height = 5)

    for (i in seq(1, length(modelos_ordenados), by = 4)) {
      graficos <- list()
      for (j in 0:3) {
        if ((i + j) <= length(modelos_ordenados)) {
          nome_modelo <- modelos_ordenados[i + j]
          ajuste <- resultados[[nome_modelo]]$ajuste

        
          plots <- plot_modelo(ajuste, dados, nome_modelo)
          graficos <- c(graficos, plots)
        }
      }
     
      grid.arrange(grobs = graficos, ncol = 4)
    }

    dev.off()  

   
    extrair_dados_modelo <- function(ajuste, nome_modelo) {
      if (is.null(ajuste)) return(NULL)

     
      parametros <- coef(ajuste)

   
      y_pred <- predict(ajuste)
      y_real <- dados$y
      res <- y_real - y_pred
      ss_res <- sum(res^2)
      ss_tot <- sum((y_real - mean(y_real))^2)
      r2 <- 1 - (ss_res / ss_tot)
      s <- sqrt(ss_res / length(y_real))

     
      dados_modelo <- data.frame(
        Modelo = nome_modelo,
        R2 = r2,
        S = s,
        a = parametros["a"],
        b = parametros["b"],
        c = ifelse("c" %in% names(parametros), parametros["c"], NA),
        d = ifelse("d" %in% names(parametros), parametros["d"], NA)
      )

      return(dados_modelo)
    }

   
    resultados_modelos <- list()

   
    for (modelo_nome in modelos_selecionados) {
      ajuste <- resultados[[modelo_nome]]$ajuste
      resultados_modelos[[modelo_nome]] <- extrair_dados_modelo(ajuste, modelo_nome)
    }

   
    resultado_final <- do.call(rbind, resultados_modelos)

   
    wb <- createWorkbook()
    addWorksheet(wb, "Modelos Ajustados")
    writeData(wb, sheet = 1, resultado_final)
    saveWorkbook(wb, file = nome_arquivo_excel, overwrite = TRUE)

    cat("Resultados salvos em", nome_arquivo_pdf, "e", nome_arquivo_excel, "\n")
  }
analise_completa(dados, modelos_selecionados, "ajustes.pdf", "modelos_ajustados.xlsx")
